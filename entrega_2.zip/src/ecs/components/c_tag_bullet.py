class CTagBullet:
    def __init__(self):
        pass
