class CTagEnemy:
    def __init__(self):
        pass
