import pygame


class CSpeed:
    def __init__(self, speed: pygame.Vector2) -> None:
        self.speed = speed
