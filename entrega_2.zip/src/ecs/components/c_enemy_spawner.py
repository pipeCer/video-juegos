from typing import List


class CEnemySpawner:
    def __init__(self, enemies: list) -> None:
        self.enemies: List = enemies
